import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class EmailDetectorTest {

    @Test
    fun detectIsEmail() {
        val detector = EmailDetector()
        assertTrue(detector.detect("a@b.c"))
        assertTrue(detector.detect("michael.childs@usu.edu"))
        assertTrue(detector.detect("{}*\$.&\$*(@*\$%&.*&*"))
    }

    @Test
    fun detectIsNotEmail() {
        val detector = EmailDetector()
        assertFalse(detector.detect("@b.c"))
        assertFalse(detector.detect("michael.childs@"))
        assertFalse(detector.detect("a @b.c"))
        assertFalse(detector.detect("a@b@c.com"))
        assertFalse(detector.detect("a.b@b.b.c"))
        assertFalse(detector.detect("michael childs@usu.edu"))
        assertFalse(detector.detect(""))
    }
}