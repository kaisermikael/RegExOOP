import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class PasswordDetectorTest {

    @Test
    fun detectIsPassword() {
        val detector = PasswordDetector()
        assertTrue(detector.detect("aaaaH!aa"))
        assertTrue(detector.detect("1234567*9J"))
        assertTrue(detector.detect("asdpoihj;loikjasdf;ijp;lij2309jasd;lfkm20ij@aH"))
        assertTrue(detector.detect("!Babcdefgh"))
        assertTrue(detector.detect("B!abcdefgh"))
    }

    @Test
    fun detectIsNotPassword() {
        val detector = PasswordDetector()
        assertFalse(detector.detect("a"))
        assertFalse(detector.detect("aaaaaaaaaa!"))
        assertFalse(detector.detect("aaaHaaaaa"))
        assertFalse(detector.detect("Abbbbbbb!"))
        assertFalse(detector.detect(""))
    }
}