import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class IntegerDetectorTest {

    @Test
    fun detectIsInteger() {
        val detector = IntegerDetector()
        assertTrue(detector.detect("1"))
        assertTrue(detector.detect("123"))
        assertTrue(detector.detect("3452342352434534524346"))
    }

    @Test
    fun detectIsNotInteger() {
        val detector = IntegerDetector()
        assertFalse(detector.detect("1.0"))
        assertFalse(detector.detect("0123"))
        assertFalse(detector.detect("123a"))
        assertFalse(detector.detect("0"))
        assertFalse(detector.detect(""))
    }
}