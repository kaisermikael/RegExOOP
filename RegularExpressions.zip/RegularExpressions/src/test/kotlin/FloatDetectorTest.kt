import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class FloatDetectorTest {

    @Test
    fun detectIsFloat() {
        val detector = FloatDetector()
        assertTrue(detector.detect("1.0"))
        assertTrue(detector.detect("123.34"))
        assertTrue(detector.detect("0.20000"))
        assertTrue(detector.detect("12349871234.12340981234098"))
        assertTrue(detector.detect(".123"))
    }

    @Test
    fun detectIsNotFloat() {
        val detector = FloatDetector()
        assertFalse(detector.detect("abc"))
        assertFalse(detector.detect("0"))
        assertFalse(detector.detect("."))
        assertFalse(detector.detect("123"))
        assertFalse(detector.detect("123.123."))
        assertFalse(detector.detect("123.02a"))
        assertFalse(detector.detect("123."))
        assertFalse(detector.detect("012.4"))
        assertFalse(detector.detect("00.12"))
        assertFalse(detector.detect(""))
    }
}