class HasCapitalState(detector: Detector): State(detector) {
    override val isValid: Boolean
        get() = false

    override fun consumeInput(string: String) {
        if (string in "!@#\$%&*") {
            detector.state = SpecialState(detector)
        }
    }
}