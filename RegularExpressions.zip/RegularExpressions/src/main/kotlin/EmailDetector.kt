class EmailDetector: Detector() {

    override var state: State = StartEmailState(this)

    override fun resetState() {
        state = StartEmailState(this)
    }

}