class BinaryDetector: Detector() {

    override var state: State = StartBinaryState(this)

    override fun resetState() {
        state = StartBinaryState(this)
    }
}