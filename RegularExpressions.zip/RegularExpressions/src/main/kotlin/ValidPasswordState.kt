class ValidPasswordState(detector: Detector): State(detector) {
    override val isValid: Boolean
        get() = true

    override fun consumeInput(string: String) {
        if (string in "!@#\$%&*") {
            detector.state = SpecialState(detector)
        }
    }
}