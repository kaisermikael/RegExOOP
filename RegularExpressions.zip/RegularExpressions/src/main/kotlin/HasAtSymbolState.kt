class HasAtSymbolState(detector: Detector): State(detector) {
    override val isValid: Boolean
        get() = false

    override fun consumeInput(string: String) {
        if (string in ".") {
            detector.state = ValidEmailState(detector)
        } else if(string in "@ ") {
            detector.state = InvalidState(detector)
        }
    }
}