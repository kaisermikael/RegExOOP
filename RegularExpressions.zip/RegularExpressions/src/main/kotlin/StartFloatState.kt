class StartFloatState(detector: Detector): State(detector) {
    override val isValid: Boolean
        get() = false

    override fun consumeInput(string: String) {
        if (string in "0") {
            detector.state = FirstZeroState(detector)
        } else if (string in ".") {
            detector.state = HasPeriodState(detector)
        } else if (string in "123456789") {
            detector.state = FirstIntState(detector)
        } else {
            detector.state = InvalidState(detector)
        }
    }
}