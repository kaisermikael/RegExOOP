class FirstSpecialState(detector: Detector): State(detector) {
    override val isValid: Boolean
        get() = false

    override fun consumeInput(string: String) {
        if (string in "ABCDEFGHIJKLMNOPQRSTUVWXYZ") {
            detector.state = ValidPasswordState(detector)
        }
    }
}