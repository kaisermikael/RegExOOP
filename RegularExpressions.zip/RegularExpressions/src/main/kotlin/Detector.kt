abstract class Detector {
    abstract var state: State

    open fun detect(input: String): Boolean {
            val characters = input
                .trim()
                .split("")
                .drop(1)
                .dropLast(1)
                .toMutableList()

            for (character in characters) {
                state.consumeInput(character)
            }
            val isValid = state.isValid
            resetState()
            return isValid
    }

    abstract fun resetState()
}