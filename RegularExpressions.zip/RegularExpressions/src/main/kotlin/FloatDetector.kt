class FloatDetector: Detector() {

    override var state: State = StartFloatState(this)

    override fun resetState() {
        state = StartFloatState(this)
    }

}