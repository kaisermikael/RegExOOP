class StartPasswordState(detector: Detector): State(detector) {
    override val isValid: Boolean
        get() = false

    override fun consumeInput(string: String) {
        if (string in "ABCDEFGHIJKLMNOPQRSTUVWXYZ") {
            detector.state = HasCapitalState(detector)
        } else if (string in "!@#\$%&*") {
            detector.state = FirstSpecialState(detector)
        }
    }
}