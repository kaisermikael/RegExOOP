class IntegerDetector: Detector() {

    override var state: State = StartIntegerState(this)

    override fun resetState() {
        state = StartIntegerState(this)
    }

}