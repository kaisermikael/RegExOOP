class ZeroState(detector: Detector): State(detector) {
    override val isValid: Boolean
        get() = false

    override fun consumeInput(string: String) {
        if (string !in "01") {
            detector.state = InvalidState(detector)
        } else if (string == "1") {
            detector.state = OneState(detector)
        }
    }
}