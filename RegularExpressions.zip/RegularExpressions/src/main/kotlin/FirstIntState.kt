class FirstIntState(detector: Detector): State(detector) {
    override val isValid: Boolean
        get() = false

    override fun consumeInput(string: String) {
        if (string in ".") {
            detector.state = HasPeriodState(detector)
        } else if (string !in "0123456789") {
            detector.state = InvalidState(detector)
        }
    }
}