class StartBinaryState(detector: Detector): State(detector) {
    override val isValid: Boolean
        get() = false

    override fun consumeInput(string: String) {
        if (string in "1") {
            detector.state = OneState(detector)
        } else {
            detector.state = InvalidState(detector)
        }
    }
}