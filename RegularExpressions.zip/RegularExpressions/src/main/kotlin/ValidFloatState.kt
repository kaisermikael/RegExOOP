class ValidFloatState(detector: Detector): State(detector) {
    override val isValid: Boolean
        get() = true

    override fun consumeInput(string: String) {
        if (string !in "0123456789") {
            detector.state = InvalidState(detector)
        }
    }
}