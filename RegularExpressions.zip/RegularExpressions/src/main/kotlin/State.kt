abstract class State(val detector: Detector) {

    abstract val isValid: Boolean

    abstract fun consumeInput(string: String)
}